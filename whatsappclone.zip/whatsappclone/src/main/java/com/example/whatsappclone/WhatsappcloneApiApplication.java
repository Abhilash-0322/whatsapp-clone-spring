package com.example.whatsappclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsappcloneApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsappcloneApiApplication.class, args);
	}

}
